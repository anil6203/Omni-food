/*$(document).ready(function(){
   
    $('.js--section-features').waypoint(
     function(direction){
      if(direction == "down") {
          $('nav').addClass('sticky');
      }else{
          $('nav').removeClass('sticky');
      }      
     });
    
});
*/
$(document).ready(function() {
    
    
    /* For the sticky navigation */
    $('.js--section-features').waypoint(function(direction){
        if (direction == "down") {
            $('nav').addClass('sticky');
        } else {
            $('nav').removeClass('sticky');
        }
    }, {
      offset: '60px;'
    });
});